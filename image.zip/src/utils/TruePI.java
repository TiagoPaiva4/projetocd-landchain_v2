//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2015   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package utils;

import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author work02
 */
public class TruePI {
    
    public static String truePi;

    static { // initialization of static members
        try {
            //read true pi
            byte[] data = Files.readAllBytes(Paths.get(TruePI.class.getClassLoader().getResource("utils/10million_pi.txt").toURI()));
            truePi = new String(data).replaceAll("\\s+", "");            
        } catch (Exception ex) {
            truePi = Math.PI + "";
        }
    }

    /**
     * gets the number of correct digits of pi string
     *
     * @param myPi pi string
     * @return number od correct digits
     */
    public static int getCorrectNumberDigits(String myPi) {
        //size of iteration
        int size = Math.min(myPi.length(), truePi.length());
        //find first difference in the strings truePi and myPi
        for (int i = 0; i < size; i++) {
            if (myPi.charAt(i) != truePi.charAt(i)) { //digit error
                return i; //return position
            }
        }
        return size; //maximum size reached
    }

    /**
     * trunks the string to correct didits of pi
     *
     * @param myPi my pi string
     * @return digits of pi
     */
    public static String getCorrectPi(String myPi) {
        return truePi.substring(0, getCorrectNumberDigits(myPi));

    }

    public static void displayPI() {
        int newLine = 1000;

        for (int i = 0; i < truePi.length(); i++) {
            if (i % newLine == 0) {
                System.out.printf("\n %10d ", i);
            }
            System.out.print(truePi.charAt(i));

        }
    }

    public static void main(String[] args) {
        String myPi = truePi;
        System.out.println("digits correct " + getCorrectNumberDigits(myPi));
        System.out.println("PI correct     " + getCorrectPi(myPi));

    }
}
