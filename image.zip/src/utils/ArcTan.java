//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     Biosystems & Integrative Sciences Institute                         ::
//::     Faculty of Sciences University of Lisboa                            ::
//::     http://www.fc.ul.pt/en/unidade/bioisi                               ::
//::                                                                         ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2022   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package utils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created on 11/11/2022, 16:12:10
 *
 * @author aulas - computer
 */
public class ArcTan extends Thread {

    public static BigDecimal arctan(BigDecimal x, int itera) {
        //build an array of threads
        int cores = Runtime.getRuntime().availableProcessors();
        ATanTHR thr[] = new ATanTHR[cores];
        //shared ticket to term index
        AtomicInteger ticket = new AtomicInteger();
        //start thrfeads
        for (int i = 0; i < thr.length; i++) {
            thr[i] = new ATanTHR(ticket, x, itera);
            thr[i].start();
        }
        //wait to threads
        BigDecimal total = new BigDecimal(0);
        for (ATanTHR t : thr) {
            try {
                t.join();
                total = total.add(t.acummulator);
            }catch (InterruptedException ex) {
            }
        }
        //return value
        return total;
    }

    private static class ATanTHR extends Thread {

        //::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        AtomicInteger ticket;
        BigDecimal acummulator;
        BigDecimal x;
        int digits;

        public ATanTHR(AtomicInteger ticket, BigDecimal x, int digits) {
            this.ticket = ticket;
            this.x = x;
            this.digits = digits;
        }

        @Override
        public void run() {
            MathContext mc = new MathContext(digits);
            //precison based on digits
            BigDecimal precision = new BigDecimal("1.0E-" + digits);
            //acumulator
            this.acummulator = BigDecimal.ZERO;
            // -1
            BigDecimal M_ONE = BigDecimal.valueOf(-1);
            //forever 
            while (true) {
                //index of next term
                int n = ticket.getAndIncrement();
                //calculate term
                BigDecimal t1 = M_ONE.pow(n).divide(BigDecimal.valueOf(2 * n + 1), mc);
                BigDecimal t2 = x.pow(2 * n + 1);
                BigDecimal term = t1.multiply(t2, mc);
                //term is less than the precision
                if (term.abs().compareTo(precision) <= 0) {
                    //terminate thread
                    break;
                }
                //add term to acumulator
                acummulator = acummulator.add(term, mc);
            }
        }
    }

    //::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    private static final long serialVersionUID = 202211111612L;
    //:::::::::::::::::::::::::::  Copyright(c) M@nso  2022  :::::::::::::::::::
    ///////////////////////////////////////////////////////////////////////////
}
