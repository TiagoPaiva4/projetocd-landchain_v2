//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2015   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package utils;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 *
 * @author work02
 */
public class AtomicBigdecimal {

    // “volatile” tells the compiler that the value of a variable
    // must never be cached as its value may change outside
    // of the scope of the program 
    private volatile BigDecimal sharedValue;

    public AtomicBigdecimal(double value) {
        this.sharedValue = BigDecimal.valueOf(value);
    }

    public synchronized BigDecimal getValue() {

        return sharedValue;
    }

    public synchronized void add(BigDecimal value) {
        sharedValue = sharedValue.add(value);
    }

    public synchronized void subtract(BigDecimal value) {
        sharedValue = sharedValue.subtract(value);
    }

    public synchronized void multiply(BigDecimal value) {
        sharedValue = sharedValue.multiply(value);
    }

    public synchronized void divide(BigDecimal value, MathContext mc) {
        sharedValue = sharedValue.divide(value, mc);
    }

    @Override
    public String toString() {
        return sharedValue.toPlainString();
    }
}
