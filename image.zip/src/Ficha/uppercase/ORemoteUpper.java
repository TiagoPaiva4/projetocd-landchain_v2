//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2024   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package Ficha.uppercase;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.SecurityUtils;

/**
 *
 * @author Trabalho
 */
public class ORemoteUpper extends UnicastRemoteObject implements IRemoteUpper {

    KeyPair serverKeys;

    public ORemoteUpper(int port) throws RemoteException, Exception {
        super(port);
        serverKeys = SecurityUtils.generateRSAKeyPair(2048);
    }

    @Override
    public String toUppercase(String msg) throws RemoteException {
        return msg.toUpperCase();
    }

    @Override
    public PublicKey getPublicKey() throws RemoteException {
        return serverKeys.getPublic();
    }

    @Override
    public byte[] toUpperCase(byte[] msg, PublicKey pkClient) throws RemoteException {
        try {
            // desecriptar a mensagem
            msg = SecurityUtils.decrypt(msg, serverKeys.getPrivate());
            //fazer o uppercase
            String resp = new String(msg).toUpperCase();
            //encriptar
            msg = SecurityUtils.encrypt(resp.getBytes(), pkClient);
            //enviar a mensagem
            return msg;
        } catch (Exception ex) {
            return "ERROR".getBytes();
        }
    }

}
