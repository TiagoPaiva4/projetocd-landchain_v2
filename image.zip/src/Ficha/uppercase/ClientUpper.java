///*****************************************************************************/
///****     Copyright (C) 2010                                             ****/
///****     António Manuel Rodrigues Manso                                  ****/
///****     e-mail: manso@ipt.pt                                            ****/
///****     url   : http://orion.ipt.pt/~manso    manso@ipt.pt              ****/
///****     Instituto Politécnico de Tomar                                  ****/
///****     Escola Superior de Tecnologia de Tomar                          ****/
///****                                                                     ****/
///*****************************************************************************/
///****     This software was build with the purpose of learning.           ****/
///****     Its use is free and is not provided any guarantee               ****/
///****     or support.                                                     ****/
///****     If you met bugs, please, report them to the author              ****/
///****                                                                     ****/
///*****************************************************************************/
///*****************************************************************************/
package Ficha.uppercase;

import java.rmi.Naming;
import java.security.KeyPair;
import java.security.PublicKey;
import utils.SecurityUtils;

/**
 *
 * @author manso
 */
public class ClientUpper {
    public static final String host = "localhost";
    public static final String remoteName = "RemoteUpper";
    public static final int remotePort = 10012;
    

    public static void main(String[] args) throws Exception {
        //adress of remote object
        String remoteObject =  String.format("//%s:%d/%s", host,remotePort, remoteName);     
        // get reference to the remote object
        IRemoteUpper remote = (IRemoteUpper) Naming.lookup(remoteObject);
        //gerar um par de chaves
        KeyPair clientKeys = SecurityUtils.generateRSAKeyPair(2048);
        //chave public do servidor
        PublicKey serverPub = remote.getPublicKey();
        //encriptar a mensagem
        byte[] secret = SecurityUtils.encrypt("hello secure world".getBytes(), serverPub);
        //enviar para o servidor
        secret = remote.toUpperCase(secret, clientKeys.getPublic());
        byte [] msg = SecurityUtils.decrypt(secret, clientKeys.getPrivate());
        System.out.println("Servar say :" + new String(msg));
        
    }

}
