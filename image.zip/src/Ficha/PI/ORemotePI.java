//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2024   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package Ficha.PI;

import java.math.BigDecimal;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.RMI;

/**
 *
 * @author Trabalho
 */
public class ORemotePI extends UnicastRemoteObject implements IRemotePI {

    IRemoteAtan server1;
    IRemoteAtan server2;

    public ORemotePI(int port) throws Exception {
        super(port);
        server1 = (IRemoteAtan) RMI.getRemote("localhost", 10_012, "ArcTan");
        server2 = (IRemoteAtan) RMI.getRemote("localhost", 10_013, "ArcTan");

    }

    @Override
    public BigDecimal pi(int precision) throws RemoteException {
        try {
            CopyOnWriteArrayList<BigDecimal> lst = new CopyOnWriteArrayList();
            Thread thr1 = new Thread(() -> {
                try {
                    BigDecimal t1 = server1.arctan(1.0 / 5.0, precision);
                    lst.add(BigDecimal.valueOf(4).multiply(t1));
                } catch (RemoteException ex) {
                    Logger.getLogger(ORemotePI.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            thr1.start();
            Thread thr2 = new Thread(() -> {
                try {
                    BigDecimal t2 = server2.arctan(1.0 / 239, precision);
                    lst.add(BigDecimal.valueOf(-1).multiply(t2));
                } catch (RemoteException ex) {
                    Logger.getLogger(ORemotePI.class.getName()).log(Level.SEVERE, null, ex);
                }

            });
            thr2.start();
            thr1.join();
            thr2.join();

            return BigDecimal.valueOf(4).multiply(lst.get(0).add(lst.get(1)));
        } catch (InterruptedException ex) {
            Logger.getLogger(ORemotePI.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        int port = 10_014;
        String name = "PI";
        Remote obj = new ORemotePI(port);
        RMI.startRemoteObject(obj, port, name);
    }

}
