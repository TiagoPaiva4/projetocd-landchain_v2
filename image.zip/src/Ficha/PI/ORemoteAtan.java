//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2024   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package Ficha.PI;

import java.math.BigDecimal;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import utils.RMI;

/**
 *
 * @author Trabalho
 */
public class ORemoteAtan extends UnicastRemoteObject implements IRemoteAtan {

    public ORemoteAtan(int port) throws RemoteException {
        super(port);
    }

    @Override
    public BigDecimal arctan(double x, int precision) throws RemoteException {
        return utils.ArcTan.arctan(BigDecimal.valueOf(x), precision);
    }
    
    public static void main(String[] args) throws Exception {
        int port = 10_013;
        String name = "ArcTan";
        Remote obj = new ORemoteAtan(port);
        RMI.startRemoteObject(obj, port, name);
    }

}
