//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2024   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package Ficha.uppercase;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.security.PublicKey;

/**
 *
 * @author M@nso 
 */
public interface IRemoteUpper extends Remote{
    //remote method 
    public String toUppercase(String msg) throws RemoteException;
    
    public PublicKey getPublicKey() throws RemoteException;
    
    public byte[]  toUpperCase(byte[] msg , PublicKey pkClient) throws RemoteException;
    
    
}
